from fastapi import APIRouter, Depends, status
from sqlalchemy import select
from sqlalchemy.orm import joinedload
from ..core.config import settings
from ..core.security import verify_password, create_access_token
from ..core.exceptions import UnauthorizedError, BadRequestError, ForbiddenError
from ..core.dependencies import get_current_user, get_repository
from ..repositories.base import IDataRepository
from ..models.user import User as UserModel
from ..schemas.auth import LoginRequest, DemoSwitchRequest, AuthResponse, UserResponse, AuthenticatedUser
from ..models.audit import AuditLog
from datetime import datetime, timezone
import uuid

router = APIRouter(prefix="/auth", tags=["Authentication"])

@router.post("/login", response_model=AuthResponse)
def login(
    req: LoginRequest,
    repository: IDataRepository = Depends(get_repository)
):
    """
    Authenticate user via email and bcrypt-hashed password.
    Returns JWT access token with role and company identity.
    """
    user = repository.get_user_by_email(req.email)
    if not user or not verify_password(req.password, user.password_hash):
        raise UnauthorizedError("Invalid email or password")

    # Generate JWT
    token = create_access_token(data={
        "sub": user.id,
        "email": user.email,
        "role": user.role,
        "company_id": user.company_id
    })

    # Log audit
    repository.log_audit(AuditLog(
        id=f"audit_{uuid.uuid4().hex[:12]}",
        user_id=user.id,
        company_id=user.company_id,
        action="AUTH_LOGIN",
        endpoint="/api/auth/login",
        details=f"User {user.email} logged in successfully"
    ))

    company_name = user.company.name if user.company else ("Global Administration" if user.role == "ADMIN" else None)

    return AuthResponse(
        access_token=token,
        token_type="Bearer",
        user=UserResponse(
            id=user.id,
            email=user.email,
            name=user.name,
            role=user.role,
            company_id=user.company_id,
            company_name=company_name,
            job_title=user.job_title
        )
    )

@router.get("/me", response_model=UserResponse)
def get_current_profile(
    current_user: AuthenticatedUser = Depends(get_current_user),
    repository: IDataRepository = Depends(get_repository)
):
    """Return currently authenticated user profile."""
    user = repository.get_user_by_id(current_user.id)
    if not user:
        raise UnauthorizedError("User not found")
    
    company_name = user.company.name if user.company else ("Global Administration" if user.role == "ADMIN" else None)

    return UserResponse(
        id=user.id,
        email=user.email,
        name=user.name,
        role=user.role,
        company_id=user.company_id,
        company_name=company_name,
        job_title=user.job_title
    )

@router.post("/demo-switch", response_model=AuthResponse)
def demo_switch(
    req: DemoSwitchRequest,
    repository: IDataRepository = Depends(get_repository)
):
    """
    Demo/Development mode switcher.
    Allows easy switching between Admin and Company Owners for client presentation.
    Disabled if ENABLE_DEMO_SWITCHER=False.
    """
    if not settings.ENABLE_DEMO_SWITCHER:
        raise ForbiddenError("Demo switcher is disabled in this environment")

    target_role = req.target_role.upper()
    if target_role == "ADMIN":
        user = repository.get_user_by_email("admin@demo.local")
    elif target_role == "OWNER":
        comp_id = req.company_id or "comp_textile_a"
        comp = repository.get_company_by_id(comp_id)
        if not comp:
            raise BadRequestError(f"Target company '{comp_id}' does not exist")
        
        with repository.get_session() as session:
            stmt = select(UserModel).options(joinedload(UserModel.company)).where(UserModel.company_id == comp_id)
            user = session.scalars(stmt).first()
            if not user:
                user = repository.get_user_by_email("owner.a@demo.local")
    else:
        raise BadRequestError("Invalid target role: Must be 'ADMIN' or 'OWNER'")

    if not user:
        raise BadRequestError("Demo user persona not found")

    token = create_access_token(data={
        "sub": user.id,
        "email": user.email,
        "role": user.role,
        "company_id": user.company_id
    })

    company_name = user.company.name if user.company else ("Global Administration" if user.role == "ADMIN" else None)

    return AuthResponse(
        access_token=token,
        token_type="Bearer",
        user=UserResponse(
            id=user.id,
            email=user.email,
            name=user.name,
            role=user.role,
            company_id=user.company_id,
            company_name=company_name,
            job_title=user.job_title
        )
    )
