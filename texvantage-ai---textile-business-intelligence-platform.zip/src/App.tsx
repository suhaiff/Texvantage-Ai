import React, { useState, useEffect } from 'react';
import { User } from './types';
import { DEMO_PERSONAS } from './data/database';
import { Navbar } from './components/Navbar';
import { AIWorkspace } from './components/AIWorkspace';
import { DashboardView } from './components/DashboardView';
import { LedgerView } from './components/LedgerView';
import { BenchmarkView } from './components/BenchmarkView';
import { SecurityView } from './components/SecurityView';
import { DatasetManager } from './components/DatasetManager';
import { apiClient } from './services/apiClient';
import { RefreshCw } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<'ai' | 'dashboard' | 'ledger' | 'datasets' | 'benchmark' | 'governance'>('dashboard');
  const [initialAIQuery, setInitialAIQuery] = useState<string | null>(null);
  const [initializing, setInitializing] = useState(true);

  // Authenticate session on mount with authoritative backend
  useEffect(() => {
    const initAuth = async () => {
      try {
        const response = await apiClient.auth.demoSwitch('OWNER', 'comp_textile_a');
        setCurrentUser(response.user);
      } catch (err) {
        console.error('Initial authentication failed, falling back to profile check:', err);
        try {
          const profile = await apiClient.auth.getProfile();
          setCurrentUser(profile);
        } catch (subErr) {
          console.error('Fallback failed:', subErr);
        }
      } finally {
        setInitializing(false);
      }
    };
    initAuth();
  }, []);

  const handleOpenAIQuery = (query: string) => {
    setInitialAIQuery(query);
    setActiveTab('ai');
  };

  const handleSwitchToAdmin = async () => {
    try {
      const response = await apiClient.auth.demoSwitch('ADMIN', null);
      setCurrentUser(response.user);
      setActiveTab('benchmark');
    } catch (err) {
      console.error('Failed to switch to admin:', err);
    }
  };

  if (initializing || !currentUser) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center space-y-4 text-white">
        <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
        <p className="text-sm font-mono text-slate-400">Authenticating with FastAPI TenantGuard...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-blue-500 selection:text-white">
      {/* Top Navigation & Persona Switcher */}
      <Navbar
        currentUser={currentUser}
        onSelectUser={user => {
          setCurrentUser(user);
        }}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Tab Views */}
      <main className="flex-1">
        {activeTab === 'ai' && <AIWorkspace key={currentUser.id} currentUser={currentUser} />}

        {activeTab === 'dashboard' && (
          <DashboardView
            currentUser={currentUser}
            onOpenAIQuery={handleOpenAIQuery}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'ledger' && <LedgerView currentUser={currentUser} />}

        {activeTab === 'datasets' && (
          <DatasetManager
            currentUser={currentUser}
            onOpenAIQuery={handleOpenAIQuery}
            onDataIngested={() => {
              // Trigger any cross-tab refresh if needed
            }}
          />
        )}

        {activeTab === 'benchmark' && (
          <BenchmarkView
            currentUser={currentUser}
            onSwitchToAdmin={handleSwitchToAdmin}
            onOpenAIQuery={handleOpenAIQuery}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'governance' && <SecurityView currentUser={currentUser} />}
      </main>
    </div>
  );
}
